#ifndef __PARSEGPS_H__
#define __PARSEGPS_H__

#include <iostream>
#include <iomanip>
#include <vector>
#include <string>

bool parse(char* data, double* lat, double* lon);


#endif
